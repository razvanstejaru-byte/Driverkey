package ro.dyad.wheelswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class SwipeService : AccessibilityService() {

    companion object {
        @Volatile var instance: SwipeService? = null
        @Volatile var learning = false
        var onLog: ((String) -> Unit)? = null
        var onLearned: ((Int) -> Unit)? = null
        val TIKTOK = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    }

    private var fg = ""
    private var session: MediaSession? = null
    private var track: AudioTrack? = null
    @Volatile private var audioRun = false
    private val prefs get() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    override fun onServiceConnected() {
        instance = this
        startMedia()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        stopMedia()
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString() ?: return
            if (!p.contains("systemui") && !p.contains("inputmethod")) fg = p
        }
    }

    // ---- Canal 1: buton ca tastă (dacă telefonul îl trimite așa) ----
    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val down = ev.action == KeyEvent.ACTION_DOWN
        onLog?.invoke(
            (if (down) "↓ " else "↑ ") + KeyEvent.keyCodeToString(ev.keyCode) +
                " (${ev.keyCode}) dev=${ev.deviceId} app=${fg.ifEmpty { "?" }}"
        )
        if (learning) {
            if (down) {
                prefs.edit().putInt("key", ev.keyCode).apply()
                learning = false
                onLearned?.invoke(ev.keyCode)
            }
            return true
        }
        if (ev.keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS && prefs.getInt("key", -1) == KeyEvent.KEYCODE_MEDIA_NEXT) {
            if (prefs.getBoolean("tiktok_only", false) && fg !in TIKTOK) return false
            if (down && ev.repeatCount == 0) run("down")
            return true
        }
        if (ev.keyCode != prefs.getInt("key", -1)) return false
        if (prefs.getBoolean("tiktok_only", false) && fg !in TIKTOK) return false
        if (down && ev.repeatCount == 0) run(prefs.getString("action", "up") ?: "up")
        return true
    }

    // ---- Canal 2: sesiune media (Bluetooth AVRCP de la mașină) ----
    fun onMediaNext() {
        onLog?.invoke("MEDIA: NEXT primit de la mașină, app=${fg.ifEmpty { "?" }}")
        if (prefs.getBoolean("tiktok_only", false) && fg !in TIKTOK) return
        run(prefs.getString("action", "up") ?: "up")
    }

    fun onMediaPrev() {
        onLog?.invoke("MEDIA: PREVIOUS primit de la mașină, app=${fg.ifEmpty { "?" }}")
        if (prefs.getBoolean("tiktok_only", false) && fg !in TIKTOK) return
        run("down")
    }

    private fun setPlaying() {
        session?.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                        PlaybackState.ACTION_PLAY_PAUSE
                )
                .setState(PlaybackState.STATE_PLAYING, 0, 1f)
                .build()
        )
    }

    private fun startMedia() {
        if (session != null) return
        val s = MediaSession(this, "WheelSwipe")
        @Suppress("DEPRECATION")
        s.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
        s.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, "Wheel Swipe")
                .putString(MediaMetadata.METADATA_KEY_ARTIST, "Next = swipe")
                .build()
        )
        s.setCallback(object : MediaSession.Callback() {
            override fun onSkipToNext() { onMediaNext() }
            override fun onSkipToPrevious() { onMediaPrev() }
            override fun onPlay() { setPlaying() }
            override fun onPause() { setPlaying() }
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                @Suppress("DEPRECATION")
                val k = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                if (k != null) onLog?.invoke("MEDIA BTN: ${KeyEvent.keyCodeToString(k.keyCode)} action=${k.action}")
                return super.onMediaButtonEvent(mediaButtonIntent)
            }
        })
        s.isActive = true
        session = s
        setPlaying()

        // Audio silențios, fără audio focus: face din sesiunea noastră ținta butoanelor media
        val rate = 8000
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(min * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        t.play()
        audioRun = true
        Thread {
            val buf = ShortArray(min)
            while (audioRun) t.write(buf, 0, buf.size)
            try { t.stop(); t.release() } catch (_: Exception) {}
        }.start()
    }

    private fun stopMedia() {
        audioRun = false
        track = null
        session?.isActive = false
        session?.release()
        session = null
    }

    // ---- Gesturi ----
    fun run(action: String) {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        when (action) {
            "up" -> swipe(w / 2, h * 0.78f, w / 2, h * 0.28f)
            "down" -> swipe(w / 2, h * 0.28f, w / 2, h * 0.78f)
            "double" -> doubleTap(w / 2, h / 2)
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 220))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun doubleTap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 50))
            .addStroke(GestureDescription.StrokeDescription(p, 130, 50))
            .build()
        dispatchGesture(g, null, null)
    }
}
