package ro.dyad.wheelswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class SwipeService : AccessibilityService() {

    companion object {
        @Volatile var instance: SwipeService? = null
        @Volatile var learning = false
        var onLog: ((String) -> Unit)? = null
        var onLearned: ((Int) -> Unit)? = null
        val TIKTOK = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    }

    private var fg = ""
    private val prefs get() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    override fun onServiceConnected() { instance = this }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString() ?: return
            if (!p.contains("systemui") && !p.contains("inputmethod")) fg = p
        }
    }

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val down = ev.action == KeyEvent.ACTION_DOWN
        onLog?.invoke(
            (if (down) "↓ " else "↑ ") + KeyEvent.keyCodeToString(ev.keyCode) +
                " (${ev.keyCode}) dev=${ev.deviceId} app=${fg.ifEmpty { "?" }}"
        )
        if (learning) {
            if (down) {
                prefs.edit().putInt("key", ev.keyCode).apply()
                learning = false
                onLearned?.invoke(ev.keyCode)
            }
            return true
        }
        if (ev.keyCode != prefs.getInt("key", -1)) return false
        if (prefs.getBoolean("tiktok_only", false) && fg !in TIKTOK) return false
        if (down && ev.repeatCount == 0) run(prefs.getString("action", "up") ?: "up")
        return true // consumă evenimentul, ca să nu-l primească alt player
    }

    fun run(action: String) {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        when (action) {
            "up" -> swipe(w / 2, h * 0.78f, w / 2, h * 0.28f)
            "down" -> swipe(w / 2, h * 0.28f, w / 2, h * 0.78f)
            "double" -> doubleTap(w / 2, h / 2)
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 220))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun doubleTap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 50))
            .addStroke(GestureDescription.StrokeDescription(p, 130, 50))
            .build()
        dispatchGesture(g, null, null)
    }
}
