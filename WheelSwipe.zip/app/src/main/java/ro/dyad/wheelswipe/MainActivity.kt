package ro.dyad.wheelswipe

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyInfo: TextView
    private lateinit var logView: TextView
    private lateinit var spin: Spinner
    private val lines = ArrayDeque<String>()
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val actions = listOf(
        "up" to "Swipe Up (video următor)",
        "down" to "Swipe Down (video anterior)",
        "double" to "Dublu tap (like)"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun btn(t: String, c: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
        background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(c) }
        layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) }
        setOnClickListener { f() }
    }

    private fun label(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); setPadding(0, dp(12), 0, dp(4))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val gray = 0xFF9CA3AF.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        root.addView(label("Wheel Swipe", 28f).apply { typeface = Typeface.DEFAULT_BOLD })
        status = label("", 16f); root.addView(status)
        root.addView(btn("1. Activează serviciul de accesibilitate", 0xFF3B82F6.toInt()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        keyInfo = label("", 16f); root.addView(keyInfo)
        root.addView(btn("2. Detectează butonul (apasă-l pe volan)", 0xFF8B5CF6.toInt()) {
            if (SwipeService.instance == null) toast("Activează întâi serviciul")
            else { SwipeService.learning = true; addLog(">> Apasă acum butonul de pe volan...") }
        })
        root.addView(btn("Setare rapidă: Next = Swipe Up", 0xFF10B981.toInt()) {
            prefs.edit().putInt("key", KeyEvent.KEYCODE_MEDIA_NEXT).putString("action", "up").apply()
            spin.setSelection(0); refresh(); toast("Next = Swipe Up")
        })
        root.addView(label("3. Acțiunea butonului", 14f, gray))
        spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, actions.map { it.second })
            setSelection(actions.indexOfFirst { it.first == prefs.getString("action", "up") }.coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    prefs.edit().putString("action", actions[pos].first).apply()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        root.addView(spin)
        root.addView(Switch(this).apply {
            text = "Doar când TikTok e în prim-plan"
            setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(4))
            isChecked = prefs.getBoolean("tiktok_only", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("tiktok_only", c).apply() }
        })
        root.addView(btn("4. Testează (peste 5 secunde)", 0xFFF59E0B.toInt()) {
            val s = SwipeService.instance
            if (s == null) toast("Activează întâi serviciul")
            else {
                toast("Deschide TikTok acum")
                val a = prefs.getString("action", "up") ?: "up"
                Handler(mainLooper).postDelayed({ s.run(a) }, 5000)
            }
        })
        root.addView(label("Evenimente primite de Android", 14f, gray))
        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(0xFF34D399.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0xFF161B22.toInt()) }
            minHeight = dp(160)
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0E1116.toInt()); isFillViewport = true; addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
        SwipeService.onLog = { s -> runOnUiThread { addLog(s) } }
        SwipeService.onLearned = { k -> runOnUiThread { refresh(); addLog(">> Asignat: ${KeyEvent.keyCodeToString(k)} ($k)") } }
    }

    override fun onPause() {
        super.onPause()
        SwipeService.onLog = null
        SwipeService.onLearned = null
        SwipeService.learning = false
    }

    private fun enabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/${SwipeService::class.java.name}")
    }

    private fun refresh() {
        val on = enabled()
        status.text = if (on) "● Serviciu activ" else "○ Serviciu inactiv"
        status.setTextColor(if (on) 0xFF34D399.toInt() else 0xFFF87171.toInt())
        val k = prefs.getInt("key", -1)
        keyInfo.text = if (k < 0) "Buton asignat: niciunul" else "Buton asignat: ${KeyEvent.keyCodeToString(k)} ($k)"
        keyInfo.setTextColor(Color.WHITE)
    }

    private fun addLog(s: String) {
        lines.addFirst(s)
        while (lines.size > 40) lines.removeLast()
        logView.text = lines.joinToString("\n")
    }
}
